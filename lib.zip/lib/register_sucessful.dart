import 'package:flutter/material.dart';
import 'profile_details.dart';



class registerSucessful extends StatefulWidget {

  @override
  _registerSucessfulState createState() => _registerSucessfulState();
}

class _registerSucessfulState extends State<registerSucessful> {

  @override
  void initState() {
    super.initState();
    new Future.delayed(
        const Duration(seconds: 3),
            () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => profileDetails()),
        ));
  }
  //
  // Widget buildSubmitButton() {
  //   return Container(
  //     // padding: EdgeInsets.symmetric(vertical: 100)
  //     padding: EdgeInsets.only(top: 120),
  //     width: 300.0,
  //     child: RaisedButton(
  //         elevation: 5,
  //         onPressed: () {
  //           Navigator.push(context, MaterialPageRoute(builder: (context) => profileDetails(),),);
  //         },
  //         // padding: EdgeInsets.all(15),
  //         padding:
  //         EdgeInsets.symmetric(vertical: 15.0, horizontal: 20.0),
  //         shape: RoundedRectangleBorder(
  //             borderRadius: BorderRadius.circular(6)
  //         ),
  //         color: Color(0xff161853),
  //         child: Text(
  //           'Done',
  //           style: TextStyle(
  //             color: Colors.white,
  //             fontSize: 18,
  //             fontWeight: FontWeight.bold,
  //           ),
  //         )
  //     ),
  //   );
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey[100],
        leading: IconButton(
            icon: Icon(Icons.arrow_back),
            color: Colors.black,
            onPressed: () =>
                Navigator.of(context).pop()
        ),
      ),
      body: Center(
        child: Column(
          children: [
            Padding(
                padding: EdgeInsets.symmetric(horizontal: 500.0,vertical: 150.0)),
            Icon(
              Icons.verified,
              color: Colors.green,
              size: 70.0,
            ),
            SizedBox(height: 40.0,),
            Text('Your Registration Done Succesfully'),
            SizedBox(height: 40.0,),
            // buildSubmitButton(),
          ],
        ),

      ),
    );
  }
}


