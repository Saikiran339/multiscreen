import 'package:flutter/material.dart';


  const kLabelTextStyle = TextStyle(
    fontSize: 15.0,
    color: Color(0xff191919),
  );