import 'package:flutter/material.dart';
import 'package:multiscreen/aadhar_verification.dart';
import 'package:multiscreen/kyc_documents.dart';
import 'package:multiscreen/loginScreen.dart';
import 'package:multiscreen/profile_details.dart';
import 'kyc_documents.dart';
import 'bank_details2.dart';
import 'loginScreen.dart';
import 'aadhar_verification.dart';
import 'profile_details.dart';


void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Navigation',
      theme: ThemeData(
        primaryColor: Colors.white,
      ),
      home: loginScreen(),
    );
  }
}



